# Per-Phase Report

This is the mandatory narrative deliverable for a section. Save it as
`repository-review/<RUN_ID>/section-summaries/<NN>-<short-name>.md`.

## Section

- Section:
- Run ID:
- Status:

## Personas applied

Which of the eight reviewer personas led this phase, and a one-line note on what
each surfaced (especially the novice and stakeholder views where relevant).

## What I did

Concrete inspections, commands, edits, and decisions made in this phase.

## Why I did it

The reasoning: the risk mitigated, the principle or persona driving each choice,
and how it improves release readiness.

## What I considered but did NOT do (mandatory)

Every notable thing examined and deliberately not done, each with an explicit
reason: out of scope, too risky, no evidence, deferred to a later run, needs a
human decision, or would violate a guiding principle. This is as important as the
work that was done.

| Considered item | Why not done | Recommended next step |
|---|---|---|
|  |  |  |

## Key findings

| ID | Type | Severity | Title | Status | Next step |
|---|---|---|---|---|---|
|  |  |  |  |  |  |

## Actions created or updated

| ID | Source IDs | Description | Status | Next step |
|---|---|---|---|---|
|  |  |  |  |  |

## Guiding-principles / self-documenting notes

Any `GP` (guiding-principles) or `U` (self-documenting / learn-as-you-go) findings
or improvements relevant to this phase, or state not applicable.

## TODO / backlog items touched

TODO.md/backlog/roadmap or in-code TODO/FIXME items triaged, fixed, reclassified,
or escalated in this phase, or state none.

## Non-applicable checks

Checks that did not apply and why.

## Decisions and assumptions

Decisions or assumptions made in this section.

## Validation or commands

Commands run and results, or why none were run.

## Handoff to next section

What the next section should know.
